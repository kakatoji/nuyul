<?php
// configurasi //


// user_name boleh kosong //
$user_name="kumpulanremaja";

//user_gaid wajib isi
$user_gaid= "a7f38e0f-d765-4d70-ac3c-558195d3a82e";
//user_token wajib di isi //
$user_token="AbwnvEj_oj-QwVtV";

//user_id wajib di isi //
$user_id="Facebook_112225456545868";

// invite_code wajib di isi //
$invite_code="FVrn6olwK";

// Bearer wajib di isi //
$Bearer="Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VySWQiOiJGYWNlYm9va18xMTIyMjU0NTY1NDU4NjgiLCJleHAiOiIxNTUxMzE1NTM1ODM2In0.xTEKRWnuBjD-i_q0Eekn9fAXTQiW3JYFNbTkD8vUlRg";



?>
